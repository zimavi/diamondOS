shell.run("rm", "/install")
shell.run("rm", "/cancel")
shell.run("rm", "/.deletetemp")